﻿using Microsoft.AspNetCore.Mvc;

namespace NipamInfotechTask.Controllers
{
    public class ProductCustomerController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
